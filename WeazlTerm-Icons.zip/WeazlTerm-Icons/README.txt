WeazlTerm icon assets

TIGER / MAC OS X 10.4
Use WeazlTerm.icns. It contains legacy RGB icon resources and separate
8-bit alpha masks at 16, 32, 48 and 128 pixels. No PNG-only modern ICNS
resources are required. Decoded and pixel-verified locally; not tested
on a running Tiger system.

Copy WeazlTerm.icns into WeazlTerm.app/Contents/Resources/ and set:
<key>CFBundleIconFile</key>
<string>WeazlTerm.icns</string>
in the app's Contents/Info.plist. In Xcode, add the ICNS to Copy Bundle
Resources. Tiger uses the ICNS, not the modern asset catalog.

OTHER ASSETS
Tiger-PNG/: transparent PNGs at all four legacy sizes.
WeazlTerm.iconset/: standard iconutil source folder for newer macOS.
AppIcon.appiconset/: modern Xcode macOS asset catalog with Contents.json.
WeazlTerm-master.png: full-resolution generated transparent artwork.

Artwork generated with built-in image generation from the supplied Weazl
reference. Prompt direction: Tiger-era silver Aqua Terminal frame, black
screen, bold white >_ prompt, pixel-art Weazl with backward lime cap and
magenta cybernetic eyepiece. PNG sizes are downsampled from the master.

Legacy resource reference:
https://chromium.googlesource.com/chromium/src/+/refs/tags/128.0.6613.5/docs/mac/icons.md
